import telebot
import requests
print('''
░█▀▀▀█ █──█ █▀▀ █── █▀▀▄ █──█ 
─▀▀▀▄▄ █▀▀█ █▀▀ █── █▀▀▄ █▄▄█ 
░█▄▄▄█ ▀──▀ ▀▀▀ ▀▀▀ ▀▀▀─ ▄▄▄█\n''')


print("Version: Beta")
print("Telegram: TheShelbyOne\n")

TOKEN = "BOT TOKEN"
bot = telebot.TeleBot(TOKEN,parse_mode=None)

@bot.message_handler(commands=["start"])
def send_help_massage(msg):
    bot.reply_to(msg,"Trying to find IDs...")
    
    message_id =msg.message_id
    id = msg.from_user.id
    
    f = "Massage ID: "+str(message_id)+"\nID: "+str(id)
    bot.reply_to(msg,f)

print("Working...")    
bot.polling()