import time
import requests
print('''
░█▀▀▀█ █──█ █▀▀ █── █▀▀▄ █──█ 
─▀▀▀▄▄ █▀▀█ █▀▀ █── █▀▀▄ █▄▄█ 
░█▄▄▄█ ▀──▀ ▀▀▀ ▀▀▀ ▀▀▀─ ▄▄▄█\n''')


print("Version: Deta")
print("Telegram: TheShelbyOne\n")

Times = input("How Many Massages: ")
chatID = input("Enter ChatID: ")
massage=input("Your massage: ")
t = input("Enter sleep time for each Massage: ")
i=1
while i < int(Times):
  def send_to_telegram(message):
    
    apiToken = 'BOT TOKEN'
    apiURL = f'https://api.telegram.org/bot{apiToken}/sendMessage'

    try:
        response = requests.post(apiURL, json={'chat_id': chatID, 'text': message})
        print(str(i)+"-Sent!")
    except Exception as e:
        print(e)

  send_to_telegram(massage)
  time.sleep(float(t))
  i+=1
  
  