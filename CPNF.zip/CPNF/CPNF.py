#County Phone Number Finder
import phonenumbers
from phonenumbers import geocoder
from termcolor import colored

print(colored('''
░█▀▀▀█ █──█ █▀▀ █── █▀▀▄ █──█ 
─▀▀▀▄▄ █▀▀█ █▀▀ █── █▀▀▄ █▄▄█ 
░█▄▄▄█ ▀──▀ ▀▀▀ ▀▀▀ ▀▀▀─ ▄▄▄█\n''',"red"))
print(colored("Version: Beta","yellow"))
print(colored("Telegram: TheShelbyOne\n","yellow"))

x = input('Enter Phone Number with county code: ')
phonenum = phonenumbers.parse(x)
print("\nPhone location found!\n")
print(geocoder.description_for_number(phonenum,"en"));