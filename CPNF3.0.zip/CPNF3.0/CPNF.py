#County Phone Number Finder 
import phonenumbers
from phonenumbers import geocoder
from termcolor import colored

print(colored('''
░█▀▀▀█ █──█ █▀▀ █── █▀▀▄ █──█ 
─▀▀▀▄▄ █▀▀█ █▀▀ █── █▀▀▄ █▄▄█ 
░█▄▄▄█ ▀──▀ ▀▀▀ ▀▀▀ ▀▀▀─ ▄▄▄█\n''',"red"))
print(colored("Version: CETA","yellow"))
print(colored("Telegram: TheShelbyOne\n","yellow"))

i=0
y= input("How many phone numbers: ")
while i<int(y):
    
    x = input('Enter Phone Number with county code: ')
    phonenum = phonenumbers.parse(x)
    print("\nPhone location found!\n")
    print(geocoder.description_for_number(phonenum,"en"));
    i+=1