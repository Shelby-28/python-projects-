import hashlib
import time
flag=0
print('''
░█▀▀▀█ █──█ █▀▀ █── █▀▀▄ █──█ 
─▀▀▀▄▄ █▀▀█ █▀▀ █── █▀▀▄ █▄▄█ 
░█▄▄▄█ ▀──▀ ▀▀▀ ▀▀▀ ▀▀▀─ ▄▄▄█\n''')


print("Version: Beta")
print("Telegram: TheShelbyOne\n")

pass_hash = input("Enter md5 hash: ")
word_list = input("Enter File Name: ")
    
try:
    pass_file = open(word_list,"r")
except:
    print("No File Found\n")



for word in pass_file:
    
    enc_wrd = word.encode('utf-8')
    digest = hashlib.md5(enc_wrd.strip()).hexdigest()
    
    print("Tested Password: "+word)
    print("Tested Hash: "+digest)
    print("Real Hash: "+pass_hash)
    time.sleep(0.1)
        
    if digest == pass_hash:
        print("Password Found !\n")
        print("Password is: " + word)
        flag=1
        break;
if flag == 0:
    print("Password is not in the list")
    
    
    
    



